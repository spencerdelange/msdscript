//
// Created by Spencer DeLange on 1/16/22.
//

#ifndef MSDSCRIPT_TEST_H
#define MSDSCRIPT_TEST_H

#include "pointer.h"

// displays the results of the test
int test(char* argv[]);

#endif //MSDSCRIPT_TEST_H
